#!/bin/bash


while [ 1 ]  ;
  do 
	./post1.sh
	sleep 5
	./post2.sh
	sleep 5
 done
