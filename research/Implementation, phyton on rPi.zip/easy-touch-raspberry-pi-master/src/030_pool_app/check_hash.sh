#redis-cli hget pool hash
redis-cli hgetall pool
